import ast
# If you are using Python 3+, import urllib instead of urllib2
import urllib.request
# from urllib2 import Request
#import urllib2
# from urllib2 import HTTPError
import json
import os.path

from flask import Flask, Response, request,render_template,send_from_directory


app = Flask(__name__)
tmpl_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
port = int(os.getenv('PORT', 8080))
@app.route("/")
def welcome():
    print(tmpl_dir)
    #content = open('templates/BreastCancer/WebContent/index.html','r')
    #return Response(content, mimetype="text/html")
    return render_template('index.html')
def root_dir():  # pragma: no cover
    return os.path.abspath(os.path.dirname(__file__))
def get_file(filename):  # pragma: no cover
    try:
        src = os.path.join(root_dir(), filename)
        return open(src).read()
    except IOError as exc:
        return str(exc)

@app.route('/getProbablity',methods=['POST'])

def getProbablity():
    ageGrp1 = request.form["prevcanProc"]
    print(ageGrp1)
    data = {

        "Inputs": {

            "input1":
                {
                    "ColumnNames": ["menopaus", "agegrp", "race",
                                    "Hispanic","bmi","agefirst","noOfFirstDegRelativesCan","prevcanProc","lastMamm",
                        "invasive"],
                    "Values": [[(ast.literal_eval(request.form.get("menopaus"))),
                                #(request.form.get("Menopaus")),

                                #(ast.literal_eval(request.form.get("agegrp"))),
                                (request.form.get("agegrp")),
                                #(ast.literal_eval(request.form.get("race"))),
                                (request.form.get("race")),
                                (request.form["Hispanic"]),
                                (request.form.get("bmi")),
                                (request.form.get("agefirst")),
                                (request.form.get("noOfFirstDegRelativesCan")),
                                (request.form["prevcanProc"]),
                                (request.form.get("lastMamm")),
                                (request.form.get("invasive"))

                                ],]
                }, },
        "GlobalParameters": {
        }
    }


    body = str.encode(json.dumps(data))


    url = 'https://ussouthcentral.services.azureml.net/workspaces/75ede20abd7a4faa931bd5a0d518d89c/services/247799d25fb4475ebe2caf4a3c35ce08/execute?api-version=2.0&details=true'
    api_key = 'ZD6nvvt06zifrmdjYtaotRA4D7/OU9LfTZw0H1mJACvlPkoF6sPQaf9prZX3TfywazArRxE2NjagDSFLPGVnWg=='  # Replace this with the API key for the web service
    headers = {'Content-Type': 'application/json', 'Authorization': ('Bearer ' + api_key)}

    req = urllib.request.Request(url, body, headers)
    #req = urllib2.Request(url, body, headers)
    # try:
    response = urllib.request.urlopen(req)
    #response = urllib2.urlopen(req)
        # If you are using Python 3+, replace urllib2 with urllib.request in the above code:
        # req = urllib.request.Request(url, body, headers)
        # response = urllib.request.urlopen(req)

    result = response.read().decode('utf-8')
    # result= json.loads(response.read())
        # for key, value in dict.items(result["ColumnNames"]):
        #     print(key, value)
    jsonList=json.loads(result)
    values=jsonList['Results']['output1']['value']['Values']
    print(result)
    print(values)
    probability=float(values[0][11])
    if (probability > 0.5):
        resultStatus="Positive"
        print(values[0][5])
    else:
        resultStatus = "Negative"
    # except urllib.error as error:
    #     print("The request failed with status code: " + str(error.code))
    #
    #     # Print the headers - they include the requert ID and the timestamp, which are useful for debugging the failure
    #     print(error.info())
    #
    #     print(json.loads(error.read()))

    #return send_from_directory('js', path)
    #return render_template('UserDashboard.html',resultStatus=resultStatus)
    probability=round(probability,2)*100
    print(probability)
    return render_template('CancerStatusResults.html',probability=probability,resultStatus=resultStatus)

@app.route('/getClassified', methods=['POST'])
def getClassified():
        ageGrp1 = request.form.get("AGE_AT_DIAGNOSIS")
        her = request.form.get("HER2_STATUS")
        print(ageGrp1)
        print(her)
        data = {

            "Inputs": {

                "input1":
                    {
                        "ColumnNames": ["AGE_AT_DIAGNOSIS", "CELLULARITY", "ER_STATUS",
                                        "HER2_STATUS", "INFERRED_MENOPAUSAL_STATE",
                                        "LATERALITY", "NPI", "PR_STATUS",
                                        "TUMOR_SIZE", "TUMOR_STAGE"],

                        "Values": [[(request.form.get("AGE_AT_DIAGNOSIS")),
                                    (request.form.get("CELLULARITY")),
                                    (request.form.get("ER_STATUS")),
                                    (request.form.get("HER2_STATUS")),
                                    (request.form.get("INFERRED_MENOPAUSAL_STATE")),
                                    (request.form.get("LATERALITY")),
                                    (request.form.get("NPI")),
                                    (request.form.get("PR_STATUS")),
                                    (request.form.get("TUMOR_SIZE")),
                                    (request.form.get("TUMOR_STAGE"))],
                                   ]
                    }, },
            "GlobalParameters": {
            }
        }

        body = str.encode(json.dumps(data))
        print(body)
        # url = 'https: // ussouthcentral.services.azureml.net / workspaces / bad877e669504b97a7e55d59b9bec551 / services / e38795a6c525496a9c767d1736f5f752 / execute?api - version = 2.0 & details = true'

        url_gt = 'https://ussouthcentral.services.azureml.net/workspaces/bad877e669504b97a7e55d59b9bec551/services/5be69ed353354b88bd8c11c455d03878/execute?api-version=2.0&details=true'
        #url = 'https://ussouthcentral.services.azureml.net/workspaces/bad877e669504b97a7e55d59b9bec551/services/e38795a6c525496a9c767d1736f5f752/execute?api-version=2.0&details=true'
        url_lt = 'https://ussouthcentral.services.azureml.net/workspaces/bad877e669504b97a7e55d59b9bec551/services/cf22d43d320c4a5b91a008652559a303/execute?api-version=2.0&details=true'
        api_key_lt = 'Ig+IY1XV0rZ4YhtMwEYfZgRijNh1gGl11Y0dtZiomLiGJLS3jqBHCGDs9YeXnsT0H/l+9vS6lXJbQoeZGz6Jcg=='  # Replace this with the API key for the web service
        api_key_gt ='q7f3A6LibYihPGWmXVoQ3Vz2sgGrLLvFQXjRfg4v88FDiBP9D9bDrr7TX5/96EPk+OAX/mFA1jM2jIEpHZFv3g=='

        if (int(ageGrp1) < 62):
            headers = {'Content-Type': 'application/json', 'Authorization': ('Bearer ' + api_key_lt)}

            req = urllib.request.Request(url_lt, body, headers)
            #req = urllib2.Request(url_lt, body, headers)
            #response = urllib.request.urlopen(req)
        if (int(ageGrp1) > 62):
            headers = {'Content-Type': 'application/json', 'Authorization': ('Bearer ' + api_key_gt)}
            req = urllib.request.Request(url_gt, body, headers)
            #req = urllib2.Request(url_gt, body, headers)
            #response = urllib.request.urlopen(req)
        # try:
        #print(req)
        response = urllib.request.urlopen(req)
        #response = urllib2.urlopen(req)
        # If you are using Python 3+, replace urllib2 with urllib.request in the above code:
        # req = urllib.request.Request(url, body, headers)
        # response = urllib.request.urlopen(req)

        result = response.read().decode('utf-8')
        # result= json.loads(response.read())
        # for key, value in dict.items(result["ColumnNames"]):
        #     print(key, value)
        jsonList = json.loads(result)
        values = jsonList['Results']['output1']['value']['Values']
        print(result)
        print(values)
        #probabilityClassBreast = float(values[0][11])
        #probabilityClassDC = float(values[0][10])
        probabilityClassID = float(values[0][10])
        probabilityClassIL = float(values[0][11])
        probabilityClassMDL = float(values[0][12])
        probabilityClassIBC = float(values[0][13])
        #probabilityClassPT = float(values[0][15])
        # probabilityClassBreast = float(values[0][19])


        resultStatus = (values[0][14])
        print(resultStatus)
        # except urllib.error as error:
        #     print("The request failed with status code: " + str(error.code))
        #
        #     # Print the headers - they include the requert ID and the timestamp, which are useful for debugging the failure
        #     print(error.info())
        #
        #     print(json.loads(error.read()))


        return render_template('CancerTypeClassResults.html', resultStatus=resultStatus,probabilityClassID=probabilityClassID,probabilityClassIL=probabilityClassIL,probabilityClassMDL=probabilityClassMDL,probabilityClassIBC=probabilityClassIBC)
if __name__ == "__main__":
    app.run()
    #app.run(host='0.0.0.0', port=port, debug=True)